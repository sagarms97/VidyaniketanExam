﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for _BLCheckin
/// </summary>
public class BusinessLayer
{
    public BusinessLayer()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    DataLayer DL = new DataLayer();



    public void ExamList(Repeater list, string SC, string IC)
    {
        string qry = @"select * from ExamMaster where SC=@sc and IC=@ic";
        DataTable dt = new DataTable();
        SqlCommand cmd = new SqlCommand();
        cmd.Parameters.AddWithValue("@sc", SC);
        cmd.Parameters.AddWithValue("@ic", IC);
        cmd.CommandText = qry;
        dt = DL.GetDataTable(cmd);
        list.DataSource = dt;
        list.DataBind();

    }
    public void que_ExamList(CheckBoxList list, string SC, string IC)
    {
        string qry = "select exam_code,exam_name  from ExamMaster where SC=@sc and IC=@ic order by exam_code ";
        DataTable dt = new DataTable();
        SqlCommand cmd = new SqlCommand();
        cmd.Parameters.AddWithValue("@sc", SC);
        cmd.Parameters.AddWithValue("@ic", IC);
        cmd.CommandText = qry;
        dt = DL.GetDataTable(cmd);
        list.DataSource = dt;
        list.DataTextField = "exam_name";
        list.DataValueField = "exam_code";
        list.DataBind();
    }
    public void CreateExam(string IC, string SC, string exam_code, string exam_name, string duration, string negative_marks, string no_of_qustions, string Exam_Instraction)
    {
        int a;
        string qry = "delete from ExamMaster where IC=@ic and SC=@sc and exam_code=@exam_code  ";

        qry += "  insert into [ExamMaster] (exam_code,exam_name,duration,negative_marks,no_of_qustions,Exam_instractions,SC,IC)";
        qry += " values( @exam_code,@exam_name,@duration,@negative_marks,@no_of_qustions,@Exam_instractions,@SC,@IC)  ";

        SqlCommand cmd = new SqlCommand();
        cmd.Parameters.AddWithValue("@ic", IC);
        cmd.Parameters.AddWithValue("@sc", SC);
        cmd.Parameters.AddWithValue("@exam_code", exam_code);
        cmd.Parameters.AddWithValue("@exam_name", exam_name);
        cmd.Parameters.AddWithValue("@duration", duration);
        cmd.Parameters.AddWithValue("@negative_marks", negative_marks);
        cmd.Parameters.AddWithValue("@no_of_qustions", no_of_qustions);
        cmd.Parameters.AddWithValue("@Exam_instractions", Exam_Instraction);



        cmd.CommandText = qry;
        DL.ExecuteCMD(cmd);
    }
    public void CreateQuestions(string ic, string question, string question_code, string sc, string option_a, string option_b, string option_c, string option_d, string answer, string solutions, string subjectcode, string examcode, string chapter, string difficulty_level, string created_date, string created_by)
    {

        string qry = "delete from QuestionMaster where IC=@ic and SC=@sc and question_code=@question_code";

        qry += "  insert into [QuestionMaster] (question_code,question,option_a,option_b,option_c,option_d,answer ,solutions,subjectcode,examcode,chapter,difficulty_level,created_by,created_date,ic,sc)";
        qry += " values( @question_code,@question,@option_a,@option_b,@option_c,@option_d,@answer ,@solutions,@subjectcode,@examcode,@chapter,@difficulty_level,@created_by,convert(date,@created_date,105),@ic,@sc)  ";

        SqlCommand cmd = new SqlCommand();
        cmd.Parameters.AddWithValue("@ic", ic);
        cmd.Parameters.AddWithValue("@question", question);
        cmd.Parameters.AddWithValue("@question_code", question_code);
        cmd.Parameters.AddWithValue("@sc", sc);
        cmd.Parameters.AddWithValue("@option_a", option_a);
        cmd.Parameters.AddWithValue("@option_b", option_b);
        cmd.Parameters.AddWithValue("@option_c", option_c);
        cmd.Parameters.AddWithValue("@option_d", option_d);
        cmd.Parameters.AddWithValue("@answer", answer);
        cmd.Parameters.AddWithValue("@solutions", solutions);
        cmd.Parameters.AddWithValue("@subjectcode", subjectcode);
        cmd.Parameters.AddWithValue("@examcode", examcode);
        cmd.Parameters.AddWithValue("@chapter", chapter);
        cmd.Parameters.AddWithValue("@difficulty_level", difficulty_level);
        cmd.Parameters.AddWithValue("@created_date", created_date);
        cmd.Parameters.AddWithValue("@created_by", created_by);


        cmd.CommandText = qry;
        DL.ExecuteCMD(cmd);
    }
    public void questionlist(Repeater list, string SC, string IC)
    {
        string qry = @"select *,Subjects.name,CONCAT('Q No.',question_code,question) as questionname from QuestionMaster INNER JOIN  dbo.Subjects ON dbo.QuestionMaster.subjectcode = dbo.Subjects.subjectcode where QuestionMaster.sc=@sc and QuestionMaster.ic=@ic order by  QuestionMaster.question_code";
        DataTable dt = new DataTable();
        SqlCommand cmd = new SqlCommand();
        cmd.Parameters.AddWithValue("@sc", SC);
        cmd.Parameters.AddWithValue("@ic", IC);
        cmd.CommandText = qry;
        dt = DL.GetDataTable(cmd);
        dt= RandomizeRows(dt);
        list.DataSource = dt;
        list.DataBind();

    }

    public DataSet questionlistWithCount( string SC, string IC,int pageNum,int pagesize)
    {

       
        int offset = pagesize * (pageNum - 1);
        string qry = String.Format(@"select *,Subjects.name,CONCAT('Q No.',question_code,question) as questionname from QuestionMaster INNER JOIN  dbo.Subjects ON dbo.QuestionMaster.subjectcode = dbo.Subjects.subjectcode where QuestionMaster.sc=@sc and QuestionMaster.ic=@ic order by  QuestionMaster.question_code offset {0} rows fetch next {1} rows only;", offset,pagesize);

        qry += "select count(*) from QuestionMaster INNER JOIN  dbo.Subjects ON dbo.QuestionMaster.subjectcode = dbo.Subjects.subjectcode where QuestionMaster.sc=@sc and QuestionMaster.ic=@ic";
        DataTable dt = new DataTable();
        SqlCommand cmd = new SqlCommand();
        cmd.Parameters.AddWithValue("@sc", SC);
        cmd.Parameters.AddWithValue("@ic", IC);
        cmd.CommandText = qry;
        DataSet ds = new DataSet();
        ds = DL.ReturnDataSet(cmd);


       
        return ds;

    }
    // changes by kusahl
    DataTable RandomizeRows(DataTable sourceDataTable)
    {
        Random random = new Random();
        DataTable randomizedDataTable = sourceDataTable.Clone();

        foreach (DataRow sourceRow in sourceDataTable.Rows)
        {
            int randomIndex = random.Next(randomizedDataTable.Rows.Count + 1);
            DataRow newRow = randomizedDataTable.NewRow();
            newRow.ItemArray = sourceRow.ItemArray;
            randomizedDataTable.Rows.InsertAt(newRow, randomIndex);
        }

        return randomizedDataTable;
    }


    public void Fill_Subjectlist(DropDownList list, string SC, string IC)
    {
        string qry = "select subjectcode,name  from Subjects where sc=@sc and ic=@ic";
        DataTable dt = new DataTable();
        SqlCommand cmd = new SqlCommand();
        cmd.Parameters.AddWithValue("@sc", SC);
        cmd.Parameters.AddWithValue("@ic", IC);
        cmd.CommandText = qry;
        dt = DL.GetDataTable(cmd);
        list.DataSource = dt;
        list.DataTextField = "name";
        list.DataValueField = "subjectcode";
        list.DataBind();
    }
    public string CreateQuestionsMaxValue()
    {
        string qry = "SELECT isnull(max(convert(int, question_code)), 0) + 1 from [QuestionMaster]";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = qry;
        SqlDataReader dtrData = (SqlDataReader)(DL.GetReader(cmd));
        if (dtrData.Read())
        {
            if (!string.IsNullOrEmpty(dtrData[0].ToString()))
            {
                qry = dtrData[""].ToString();
            }
        }
        return qry;
    }
    public string CreateExamMaxValue()
    {
        string qry = "SELECT isnull(max(convert(int, exam_code)), 0) + 1 from [ExamMaster]";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = qry;
        SqlDataReader dtrData = (SqlDataReader)(DL.GetReader(cmd));
        if (dtrData.Read())
        {
            if (!string.IsNullOrEmpty(dtrData[0].ToString()))
            {
                qry = dtrData[""].ToString();
            }
        }
        return qry;
    }

   
    public void Execute(string qry)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = qry;
        DL.ExecuteCMD(cmd);
    }
     
    public string ReturnString(string qry)
    {

        string result = "";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = qry;
        SqlDataReader dtrData = (SqlDataReader)(DL.GetReader(cmd));
        if (dtrData.Read())
        {
            if (!string.IsNullOrEmpty(dtrData[0].ToString()))
            {
                result = dtrData[0].ToString();
            }
        }
        return result;
    }
    public DataSet ReturnDataSet(string qry)
    {


        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = qry;
        return (DL.ReturnDataSet(cmd));

    }
    
 
  




}